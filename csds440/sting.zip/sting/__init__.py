"""top level module for sting library source
"""
